// 动态背景初始化（仅在非"none"时执行）
document.addEventListener('DOMContentLoaded', function() {
    const bgType = 'particles';
    
    if (bgType === 'particles') initParticles();
    else if (bgType === 'waves') initWaves();
    else if (bgType === 'stars') initStars();
});

// 粒子效果
function initParticles() {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.zIndex = '-1';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    const particles = [];
    const particleCount = window.innerWidth < 768 ? 30 : 50;

    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: Math.random() * 3 + 1,
            speedX: Math.random() * 1 - 0.5,
            speedY: Math.random() * 1 - 0.5
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';

        particles.forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();

            p.x += p.speedX;
            p.y += p.speedY;

            if (p.x < 0 || p.x > canvas.width) p.speedX *= -1;
            if (p.y < 0 || p.y > canvas.height) p.speedY *= -1;
        });

        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', function() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// 波浪效果
function initWaves() {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.zIndex = '-1';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    let time = 0;

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.beginPath();

        for (let x = 0; x < canvas.width; x++) {
            const y = Math.sin(x * 0.01 + time) * 15 + canvas.height / 2;
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }

        ctx.lineTo(canvas.width, canvas.height);
        ctx.lineTo(0, canvas.height);
        ctx.closePath();
        ctx.fill();

        time += 0.05;
        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', function() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// 星空效果
function initStars() {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.zIndex = '-1';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    const stars = [];
    const starCount = window.innerWidth < 768 ? 60 : 100;

    for (let i = 0; i < starCount; i++) {
        stars.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: Math.random() * 2 + 0.5,
            alpha: Math.random() * 0.8 + 0.2
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        stars.forEach(star => {
            ctx.fillStyle = `rgba(255, 255, 255, ${star.alpha})`;
            ctx.beginPath();
            ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            ctx.fill();

            star.alpha += Math.random() * 0.1 - 0.05;
            if (star.alpha < 0.2) star.alpha = 0.2;
            if (star.alpha > 1) star.alpha = 1;
        });

        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', function() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// 页面初始化
document.addEventListener('DOMContentLoaded', () => {
    // 更新日期时间
    updateDateTime();
    
    // 显示主内容
    setTimeout(() => {
        const container = document.getElementById('container');
        container.style.opacity = '1';
        container.style.transform = 'none';
        
        // 显示网站网格
        document.querySelector('.app-grid').style.opacity = '1';
        document.querySelector('.app-grid').style.transform = 'none';
        
        // 显示页脚
        document.querySelector('footer').style.opacity = '1';
        
        // 隐藏加载器
        setTimeout(() => {
            document.getElementById('loader').classList.add('hidden');
            
        }, 400);
    }, 400);
    
    // 设置时间更新定时器
    setInterval(updateDateTime, 1000);
    
    // 添加应用点击事件
    setupAppLinks();
    
    
    // 移除访问量功能（已改为一言）
    
    
    // 获取一言
    fetchHitokoto();
});

// 更新时间函数
function updateDateTime() {
    const now = new Date();
    
    // 格式化时间
    const timeStr = now.toLocaleTimeString('zh-CN', {
        hour: '2-digit',
        minute: '2-digit'
    });
    
    // 格式化日期
    const dateOptions = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long'
    };
    const dateStr = now.toLocaleDateString('zh-CN', dateOptions);
    
    // 更新DOM
    document.getElementById('time').textContent = timeStr;
    document.getElementById('date').textContent = dateStr;
}

// 应用链接配置
const appLinks = {
    "花旗解析": "https://api.huaqi.pro",
    "花旗播放器": "http://www.huaqi.live",
    "花旗弹幕": "https://danmu.huaqi.pro",
    "花旗资源": "https://www.seacms.org",
    "花旗图床": "https://image.huaqi.pro",
    "花旗探针": "https://nezha.huaqi.pro",
    "佐佐网": "https://www.zuoz.net",
    "TG客服": "https://t.me/huaqiads",
    "TG群": "https://t.me/huaqizy"
};

// 应用点击事件设置
function setupAppLinks() {
    document.querySelectorAll('.app-item').forEach(item => {
        item.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 200);
            
            const appName = this.getAttribute('data-app-name');
            const link = appLinks[appName];
            
            if (link) {
                setTimeout(() => {
                    if (link.startsWith('mailto:')) {
                        window.location.href = link;
                    } else {
                        window.open(link, '_blank');
                    }
                }, 300);
            }
        });
    });
}





// 获取一言
function fetchHitokoto() {
    fetch('https://v1.hitokoto.cn/?c=k&encode=json')
        .then(response => response.json())
        .then(data => {
            const hitokoto = document.getElementById('hitokoto');
            
            if (hitokoto) {
                let displayText = data.hitokoto;
                if (data.from) {
                    displayText += ` —— 《${data.from}》`;
                }
                hitokoto.textContent = displayText;
            }
        })
        .catch(error => {
            console.log('一言获取失败:', error);
            const hitokoto = document.getElementById('hitokoto');
            if (hitokoto) {
                hitokoto.textContent = '生活就像一盒巧克力，你永远不知道下一颗是什么味道。 —— 《阿甘正传》';
            }
        });
}

// 每30分钟更新一次一言
setInterval(fetchHitokoto, 30 * 60 * 1000);

// 添加键盘快捷键
document.addEventListener('keydown', function(e) {
    // Ctrl + K 打开搜索（示例）
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        // 这里可以添加搜索功能
        console.log('搜索功能待实现');
    }
    
});

// 添加滚动效果
window.addEventListener('scroll', function() {
    const scrolled = window.pageYOffset;
    const container = document.querySelector('.container');
    
    if (container) {
        const parallax = scrolled * 0.1;
        container.style.transform = `translateY(${parallax}px)`;
    }
});

// 添加点击涟漪效果
function createRipple(event, element) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(92, 172, 238, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
        z-index: 10;
    `;
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// 为所有应用项添加涟漪效果
document.querySelectorAll('.app-item').forEach(item => {
    item.addEventListener('click', function(e) {
        createRipple(e, this);
    });
});

// 添加涟漪动画CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// 性能优化：节流函数
function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 应用节流到滚动事件
const throttledScroll = throttle(() => {
    // 滚动相关优化
}, 16);

window.addEventListener('scroll', throttledScroll);